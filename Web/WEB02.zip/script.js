const cachedToken = "\u0045\u006e\u006e\u0061\u0020\u0064\u0061\u0020\u004e\u006f\u0069\u0069\u0020\u004e\u006f\u0069\u0069\u0020\u006e\u0067\u0072\u0061\u002e\u002e\u002e";

function renderComment() {
  const params = new URLSearchParams(window.location.search);
  const comment = params.get("comment");
  if (comment !== null) {
    document.getElementById("output").innerHTML = comment; // vulnerable sink
  }
}

async function revealFlag() {
  const res = await fetch("/api/flag", {
    headers: { "X-Cybroid-Fetch": "1" }
  });
  const data = await res.json();
  return data.flag;
}

window.onload = renderComment;
