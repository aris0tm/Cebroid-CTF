from flask import Flask, render_template, jsonify, request

app = Flask(__name__)

REAL_FLAG = "Cybroid{d3pr35510n_fr0m_c0nfu710n}"


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/api/flag")
def api_flag():
    # Soft gate: only responds to requests carrying this header, which is
    # only ever sent by the page's own JS (see revealFlag() in script.js).
    # Not real auth -- a team that reads script.js closely enough can
    # replicate it with curl too, and that's an acceptable alt-solve.
    if request.headers.get("X-Cybroid-Fetch") != "1":
        return jsonify({"error": "forbidden"}), 403
    return jsonify({"flag": REAL_FLAG})


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
